package pkg2;

public class C {
	static void mc1(String strc1) {
	}
	static void mc2(String strc2, int ict2) {
	}
}

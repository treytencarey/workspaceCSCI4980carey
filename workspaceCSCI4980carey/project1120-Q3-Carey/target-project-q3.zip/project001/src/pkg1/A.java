package pkg1;

final class A {
	private void ma1(int str1) {
	}
	
	private void ma2(String str1, int i1) {
	}
}

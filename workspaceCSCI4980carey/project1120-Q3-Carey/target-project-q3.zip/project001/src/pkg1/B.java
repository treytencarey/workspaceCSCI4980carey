package pkg1;

final class B {
	public void mb1(String str1) {
	}
	
	public void mb2(String str1, int b2) {
	}
}
